<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>RHM Home</title>
  <link rel="stylesheet" href="/css/app.css" media="screen" title="no title" charset="utf-8">
  <style>
  html, body {
    height: 100%;
  }

  html {
    display: table;
    margin: auto;
  }

  body {
    display: table-cell;
    vertical-align: middle;
    text-align: center;
  }
  </style>
</head>
<body>

  <h1>-: Welcome To HRM :-</h1>
  <h3>Easy & hassle free <br>HousE rENT Management</h3>
  <h4>      <strong>Email:</strong> admin@HRM.com ||
    <strong>Password:</strong> demo123
  </h4>
  <a href="/login" class="btn btn-primary btn-lg">
    <i class="glyphicon glyphicon-log-in"></i> Login
  </a>

</body>
</html>
