  <!-- footer content -->
  <footer class="footer_fixed">
    <div class="pull-right">
        <!-- Don't remove below text. Its againts copy right laws. -->
    <strong>House Rent Management System Version 1.0 - {{substr($idc,0,7)}}</strong> || Developed by <a href="https://shanixlab.com">ShanixLab</a>
    </div>
    <div class="clearfix"></div>
  </footer>
  <!-- /footer content -->
</div>
</div>